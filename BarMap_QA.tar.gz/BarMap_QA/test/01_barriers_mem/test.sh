#!/bin/bash
# File  : 01_barriers_mem/test.sh
# Author: Felix Kuehnl
# Date  : 2017-10-23

# Enable 'unofficial strict mode'.
#   -e: exit immediately if any command has non-zero return value. This can be
#       escaped by appending '|| true' to a command, or use
#       'set +e; cmd; set -e'
#   -u: exit immediately when an unset variable is dereferenced
#   -o pipefail: pipelines return the error code of the rightmost command that
#       failed (instead of always returning the value of the rightmost
#       command). Result with -e: script exits if any subcommand within a pipe
#       fails.
set -euo pipefail

# Abort on errors, displaying error message + code, kill all running jobs.
clean_and_die() {
    error_code="$1"; error_message="$2"
    echo -e "\nERROR: $error_message ($error_code) in script" \
        "'$(basename $0)'" 1>&2
    jobs=$(jobs -pr); [ -z "$jobs" ] || kill $(jobs -pr)
    exit $error_code
}

trap 'clean_and_die $? "terminated unexpectedly at line $LINENO"' ERR
trap 'clean_and_die $? "interrupted"'           INT
trap 'clean_and_die $? "caught TERM signal"'    TERM


##############################################################################
##                              Script options                              ##
##############################################################################

# Name and version of this script
SCRIPT_NAME='00_help/test.sh'
SCRIPT_VERSION='v0.1'

# Number of positional args. Set negative to disable check.
NO_POSITIONAL_ARGS=0

# Set options to parse here. Colon (:) after letter means option has a value.
OPT_STRING='vh'

HEADING=$( perl -e '        # Center string by adding padding spaces
    $line_length=78; $s="* * * @ARGV * * *"; $pad=($line_length-length $s)/2;
    $pad=0 if $pad<0; print " " x $pad, $s
' $SCRIPT_NAME $SCRIPT_VERSION )
usage=$( cat <<EndOfUsage
$HEADING

Test whether all scripts can be run using the -h help switch and whether the
Perl modules can be loaded.

Usage:  $SCRIPT_NAME [ARGS]

Arguments:  [...] denotes default values, xx doubles, ii ints, ss strings
    -v:     Be verbose and show debug messages.
    -h:     Display this help and exit.
EndOfUsage
)
unset HEADING


##############################################################################
##                              Core functions                              ##
##############################################################################

# Display passed error message an exit with error code 1
die() {
    echo "ERROR: $*" 1>&2; exit 1
}

# # Check whether global error flag $? is set and if so, die with the
# # passed error message
# assert() {
#     [ $? -ne 0 ] && die "$@"
# }

# Ensure existence and non-emptiness of a (regular) file
# Arguments:
#   file_name, and optionally
# Optional arguments:
#   file_description: To be displayed in error message [File]
#   can_be_empty: Whether empty files are allowed [false]
assert_file_exists() {
    local file_name="$1"
    local file_description="${2-File}"
    local can_be_empty=${3:-}
    local error=
    local message=

    [ -f "$file_name" ] || { error=1; message='not found'; }
    [ ! -n "$error" ] && [ ! -n "$can_be_empty" ] && [ ! -s "$file_name" ] &&
        { error=1; message='is empty'; }

    [ -z "$error" ] ||
        die "$file_description '$file_name' $message"
}

# Print a message if global variable is set, usually via -v switch
dbgm() {
    if [ -n "${BE_VERBOSE-}" ]; then
        echo "$@" 1>&2
    fi
    return 0
}

# Indent all text piped through with n spaces.
# Argument: n -- amount of spaces to indent [4]
indent() {
    local indent=${1-4}     # indent 4 spaces by default
    perl -pe "print q{ } x $indent"
}


##############################################################################
##                              Default values                              ##
##############################################################################

BE_VERBOSE=${BE_VERBOSE:+1}
n=$'\n'                 # Newline
t=$'\t'                 # Tab
export LC_COLLATE='C'   # set sys language to C to avoid problems with sorting
export LC_NUMERIC='C'   # also recognize '.' as decimal point


##############################################################################
##                              Option parsing                              ##
##############################################################################

while getopts "$OPT_STRING" opt; do
    case $opt in
#       e)
#           example=$OPTARG ;;
        v)
            BE_VERBOSE=1 ;;
        h)
            echo "$usage"
            exit 0
            ;;
        *)
            die "Invalid option, use -h to get help."
    esac
done

#### Positional params ####
shift $(($OPTIND-1))       # shift positional parameters to position 1, 2, ...
wrongNoParamMsg='Wrong number of positional parameters, use -h to get help'
[ $# -eq $NO_POSITIONAL_ARGS ] || [ $NO_POSITIONAL_ARGS -lt 0 ] ||
    die "$wrongNoParamMsg"


#### Collect positional args ####
# Use array/"${var[@]}" notation to preserve file names containing whitespace
# input_files=("$@")


#### Print debug output like e. g. passed arguments ####
dbgm "                      * * * $SCRIPT_NAME $SCRIPT_VERSION  * * *"


##############################################################################
##                           Function definitions                           ##
##############################################################################

# Filter out Barriers' default log messages and only print errors etc.
filter_bar_stderr() {
    perl -wne '
            print STDERR $_ unless m{
                  ^ Warning:[ ]obscure[ ]headline[ ]in[ ]input[ ]file
                | ^ hashbits[ ]=
                | ^ read[ ]\d+[ ]structures,[ ]to[ ]find
                | ^ \d+[ ]hash[ ]table[ ]collisions
                | ^ want_connected[ ]is
                | ^ done[ ]with[ ]2nd[ ]pass
                | ^ rate[ ]matrix[ ]written[ ]to[ ]binfile
                | ^ increasing[ ]lmin[ ]array[ ]to
            }x
        '
}


##############################################################################
##                                   Main                                   ##
##############################################################################

# Some random sequence.
sequence='GCGCGUGUCCUUUAAACCUAUAUCGUGUCU'


tmp_dir="$( mktemp --directory tmp_dir_XXXXX )"
cd "$tmp_dir"

# Run barriers to catch memory errors. A high number of hash bits can lead to
# problems on systems with small amounts of RAM (<=4GB).
bar_file='bar.out'
echo "$sequence" |
    RNAsubopt -se 5 |
    barriers --quiet 2>&1 >"$bar_file" |
    filter_bar_stderr

# Test that we found enough minima to catch bugged Barriers versions. Note
# that the exact count of mins may vary since shift moves are turned off by
# default beginning with version 1.7.0.
min_count="$( wc --lines < "$bar_file" )"
[ "$min_count" -ge 20 ] ||
    die "Found only $min_count minima, expected at least 20. Are you using"\
        'the bugged version 1.7.0 of Barriers?'

cd ..
rm -rf "$tmp_dir"

exit 0
# EOF

