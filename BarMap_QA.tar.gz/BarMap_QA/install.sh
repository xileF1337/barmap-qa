#!/bin/bash
# Install / update this software.

# Strict mode: die on non-0 exit codes (-e) or when dereferencing unset
# variables (-u), propagate ERR traps to subshells (-E), and make pipes return
# exit code of first error (-o pipefail).
set -euo pipefail

# Abort on errors, displaying error message + code, kill all running jobs.
clean_and_die() {
    error_code="$1"; error_message="$2"
    echo -e "\nERROR: $error_message ($error_code) in script" \
        "'$(basename $0)'" 1>&2
    jobs=$(jobs -pr); [ -z "$jobs" ] || kill $(jobs -pr)
    exit $error_code
}

trap 'clean_and_die $? "terminated unexpectedly at line $LINENO"' ERR
trap 'clean_and_die  1 "interrupted"'           INT
trap 'clean_and_die  1 "caught TERM signal"'    TERM

# Display error message and exit with code 1.
die()  { echo   "ERROR: $*" 1>&2; exit 1; }

##############################################################################
##                                Functions                                 ##
##############################################################################

# Check that a required version of ViennaRNA is installed and available.
check_viennarna_version() {
    cpanm 'version'
    perl -wle '
        use version 0.77;

        eval {require RNA; RNA->import(); };
        die "Please install the ViennaRNA package including its Perl ",
            "bindings. Make sure RNA.pm is contained in your PERL5LIB ",
            "environment variable, e.g. by running:\n",
            q<    export PERL5LIB="/path/to/RNA.pm:$PERL5LIB">, "\n",
            "Source code and pre-compiled packages of ViennaRNA are ",
            "available at its homepage at <www.tbi.univie.ac.at/RNA/>."
          if $@;

        my $rna_ver = version->parse(RNA::VERSION());
        my $min_rna_ver = version->declare("v2.4.13");
        die "Found ViennaRNA $rna_ver bindings, but need at least $min_rna_ver"
            unless $rna_ver >= $min_rna_ver;
    '
}


##############################################################################
##                                   Main                                   ##
##############################################################################

# Check whether cpanminus is installed and available.
type -p 'cpanm' >/dev/null ||
    die 'Please install cpanminus, the Perl package manager. On Ubuntu, run'\
        '`sudo apt install cpanminus`; on Fedora, run'\
        '`sudo dnf install perl-App-cpanminus`; or install via cpan with'\
        '`cpan install App::cpanminus`.'

# Check ViennaRNA including Perl bindings are present.
check_viennarna_version

# Install additional Perl dependencies of the scripts and dists.
additional_perl_deps=(
    'Data::Dumper'
    'IO::Pager'
    'IO::Null'
    'IPC::System::Simple'
    'YAML::LibYAML'                     # contains YAML::XS
)
cpanm "${additional_perl_deps[@]}"

# Install Perl distributions.
for dist_tarball in perl_dist/*; do
    cpanm "$dist_tarball"
done

# Add bin to PATH.
dist_bin="$(realpath ./bin)"
export PATH="$dist_bin:$PATH"

# Add perl5 libs (barrier.pm) to PERL5LIB
dist_perl5lib="$(realpath ./perl5lib)"
export PERL5LIB="$dist_perl5lib:${PERL5LIB-}"

# Run tests.
make test

echo "Add '$dist_bin' to your PATH,"
echo "and '$dist_perl5lib' to your PERL5LIB, e. g. by running"
echo "    export PATH=\"$dist_bin:\$PATH\" "
echo "    export PERL5LIB=\"$dist_perl5lib:\$PERL5LIB\" "
echo 'Add both to your ~/.bashrc to have everything ready to use.'

exit 0                          # EOF

